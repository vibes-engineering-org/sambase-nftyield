export const PROJECT_TITLE = "NFTYield";
export const PROJECT_DESCRIPTION = "Track and optimize your NFT portfolio yields across multiple blockchains";
export const PROJECT_CREATOR = "sambase";
export const PROJECT_AVATAR_URL =
  "https://wrpcd.net/cdn-cgi/imagedelivery/BXluQx4ige9GuW0Ia56BHw/37460dae-996e-481a-9c2c-0374da719400/anim=false,fit=contain,f=auto,w=576";
